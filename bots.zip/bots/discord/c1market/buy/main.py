import os
import json
import asyncio
import logging
import discord
from discord.ext import commands
from discord import app_commands


TOKEN = "MTQwNjA5NTY0MjYzOTQ2NjUzNg.GgxAT1.xTzHJm-zLehhQcBqfDcU833OQYHU1v0EbTEIIk"   # <-- Reemplaza por tu token real (no lo compartas)


INTENTS = discord.Intents.default()
INTENTS.guilds = True
INTENTS.members = True
INTENTS.message_content = True


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s"
)
log = logging.getLogger("c1bot")


bot = commands.Bot(command_prefix="!", intents=INTENTS)


DATA_DIR = "data"
CONFIG_FILE = os.path.join(DATA_DIR, "config.json")
STOCK_FILE = os.path.join(DATA_DIR, "stock.json")
os.makedirs(DATA_DIR, exist_ok=True)


if not os.path.exists(CONFIG_FILE):
    with open(CONFIG_FILE, "w") as f:
        json.dump(
            {
                "canal_vouch_id": None,
                "tickets_category_name": "tickets-buy",
                "tickets_category_id": None,
                "support_role_id": None,
                "support_user_id": None,
                "paypal": "simplelogin-newsletter.cleft382@simplelogin.com",
                "wallets": {
                    "BTC": "Open ticket",
                    "USDC": "Open ticket",
                    "ETH": "Open ticket",
                    "LTC": "Open ticket",
                    "SOL": "Open ticket",
                    "DOGE": "Open ticket"
                }
            },
            f,
            indent=4,
        )
if not os.path.exists(STOCK_FILE):
    with open(STOCK_FILE, "w") as f:
        json.dump({}, f, indent=4)


def load_config():
    with open(CONFIG_FILE, "r") as f:
        return json.load(f)

def save_config(cfg):
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=4)


PRODUCTO_TITULO = "``『 C1 | Find 』``"
PRODUCTO_PRECIO = ""
PRODUCTO_IMAGEN_URL = "https://media.discordapp.net/attachments/1404229650397266000/1404235745886994432/Nouveau_projet8_1.png?ex=68f8b733&is=68f765b3&hm=914d4440001b8745dc52fae5aa96142de44bdf5dd532d1db6f3e2619b0fdabf5&=&format=webp&quality=lossless&width=1217&height=492" 

PRODUCTO_DESCRIPCION = """Your Ally in the Private and Advanced Search for Information

C1.Find is a next-generation private search tool designed for researchers, analysts and professionals who require fast, secure and accurate access to high-value information.
Connected to globally exclusive databases, this bot employs optimized algorithms that deliver reliable results in less than 3 seconds.

Featured capabilities:
Access to global information in private and segmented databases.

Coverage on game servers and entertainment platforms:

[+] FiveM

[+] Minecraft

[+] Roblox

[+] Others.

Searches by multiple criteria, including:

[+] Emails

[+] Telephone numbers

[+] National identity documents (DNI)

[+] Addresses and street names

[+] Health card numbers

[+] Other specific identifiers.

Consultation in sources not publicly indexed, ideal for in-depth research (deep data).

Advantages of c1.find:
✅ Speed – Results in a matter of seconds.
✅ Accuracy – Clear, filtered and verifiable data.
✅ Privacy – Encrypted searches, without tracking or improper storage.
✅ Exclusivity – Access to restricted information for authorized users.


Ideal for OSINT, digital investigations, cybersecurity, identity verification, fraud analysis and location of sensitive information.
"""


async def crear_ticket(interaction: discord.Interaction, metodo_pago: str, ref_texto: str):
    """Create ticket channel with permissions and mention support role."""
    cfg = load_config()
    guild = interaction.guild

    # 1. Obtener/Crear Categoría
    categoria = None
    category_id = cfg.get("tickets_category_id")
    category_name = cfg.get("tickets_category_name") or "tickets-buy"
    
    if category_id:
        try:
            categoria = guild.get_channel(int(category_id))
        except (TypeError, ValueError):
            pass

    if not isinstance(categoria, discord.CategoryChannel):
        categoria = discord.utils.get(guild.categories, name=category_name)
    
    if not isinstance(categoria, discord.CategoryChannel):
        log.info(f"Creating new ticket category: {category_name}")
        categoria = await guild.create_category(category_name)

    # 2. Definir Permisos y Rol de Soporte
    overwrites = {
        guild.default_role: discord.PermissionOverwrite(view_channel=False),
        interaction.user: discord.PermissionOverwrite(view_channel=True, send_messages=True, attach_files=True),
    }
    
    soporte_rol = None
    support_role_id = cfg.get("support_role_id")
    if support_role_id:
        try:
            soporte_rol = guild.get_role(int(support_role_id))
            if soporte_rol:
                overwrites[soporte_rol] = discord.PermissionOverwrite(view_channel=True, send_messages=True)
            else:
                log.warning(f" {support_role_id} error id.")
        except (ValueError, TypeError):
            log.error(f"The support_role_id '{support_role_id}' in config.json is invalid.")

    # 3. Crear Canal de Ticket
    channel_name = f"Ticket-{interaction.user.name}".lower().replace(" ", "-")[:90]
    canal_ticket = await guild.create_text_channel(
        name=channel_name,
        category=categoria,
        overwrites=overwrites,
        reason=f"Ticket {interaction.user}",
    )

    # 4. Enviar Mensaje de Bienvenida
    embed = discord.Embed(
        title="🎫 Payment ticket",
        description=(
            f"Created for {interaction.user.mention}\n\n"
            f"**Method:** {payment_method}\n"
            f"**Wallet:**\n```{ref_text}```\n"
            "Send the receipt to continue."
        ),
        color=discord.Color.dark_grey(),
    )
    embed.set_footer(text="Support C1 | Find")

    mention_text = interaction.user.mention
    if soporte_rol:
        mention_text += f" {soporte_rol.mention}"

    await canal_ticket.send(
        content=mention_text,
        embed=embed,
        allowed_mentions=discord.AllowedMentions(everyone=False, users=True, roles=True),
    )
    return canal_ticket

class CryptoView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    async def _mostrar_wallet(self, interaction: discord.Interaction, metodo: str, wallet: str):
        await interaction.response.send_message("Creating your ticket...", ephemeral=True)
        canal_ticket = await crear_ticket(interaction, metodo, wallet)

        class TicketLink(discord.ui.View):
            def __init__(self, url: str):
                super().__init__(timeout=None)
                self.add_item(discord.ui.Button(label="Go to ticket", style=discord.ButtonStyle.link, url=url))

        ticket_url = f"https://discord.com/channels/{interaction.guild_id}/{canal_ticket.id}"
        await interaction.followup.send(
            f"💳 Payment method: **{metodo}**\n📌 Wallet:\n```{wallet}```\n"
            f"After sending the payment, open the ticket and attach the receipt.",
            view=TicketLink(ticket_url),
            ephemeral=True,
        )

    @discord.ui.button(label="``BTC``", style=discord.ButtonStyle.primary)
    async def btn_btc(self, i: discord.Interaction, b: discord.ui.Button):
        cfg = load_config(); await self._mostrar_wallet(i, "Bitcoin", cfg["wallets"]["BTC"])

    @discord.ui.button(label="``USDC``", style=discord.ButtonStyle.success)
    async def btn_usdc(self, i: discord.Interaction, b: discord.ui.Button):
        cfg = load_config(); await self._mostrar_wallet(i, "USDC", cfg["wallets"]["USDC"])

    @discord.ui.button(label="``ETH``", style=discord.ButtonStyle.secondary)
    async def btn_eth(self, i: discord.Interaction, b: discord.ui.Button):
        cfg = load_config(); await self._mostrar_wallet(i, "Ethereum", cfg["wallets"]["ETH"])

    @discord.ui.button(label="``LTC``", style=discord.ButtonStyle.primary)
    async def btn_ltc(self, i: discord.Interaction, b: discord.ui.Button):
        cfg = load_config(); await self._mostrar_wallet(i, "Litecoin", cfg["wallets"]["LTC"])

    @discord.ui.button(label="``Solana``", style=discord.ButtonStyle.success)
    async def btn_solana(self, i: discord.Interaction, b: discord.ui.Button):
        cfg = load_config(); await self._mostrar_wallet(i, "Solana", cfg["wallets"]["SOL"])

    @discord.ui.button(label="``Dogecoin``", style=discord.ButtonStyle.secondary)
    async def btn_doge(self, i: discord.Interaction, b: discord.ui.Button):
        cfg = load_config(); await self._mostrar_wallet(i, "Dogecoin", cfg["wallets"]["DOGE"])

class PagoView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="💰 Crypto", style=discord.ButtonStyle.primary)
    async def pago_crypto(self, i: discord.Interaction, b: discord.ui.Button):
        await i.response.send_message("Select the cryptocurrency:", view=CryptoView(), ephemeral=True)

    @discord.ui.button(label="💳 PayPal", style=discord.ButtonStyle.success)
    async def pago_paypal(self, i: discord.Interaction, b: discord.ui.Button):
        cfg = load_config()
        await i.response.send_message("Creating your ticket...", ephemeral=True)
        canal = await crear_ticket(i, "PayPal", cfg.get("paypal") or "no-configurado")
        url = f"https://discord.com/channels/{i.guild_id}/{canal.id}"
        class TicketLink(discord.ui.View):
            def __init__(self, url: str):
                super().__init__(timeout=None)
                self.add_item(discord.ui.Button(label="Ir al ticket", style=discord.ButtonStyle.link, url=url))
        await i.followup.send("Ticket created. Share your receipt on the ticket.", view=TicketLink(url), ephemeral=True)

# Botón persistente de Comprar (con callback real)
class ComprarButton(discord.ui.Button):
    def __init__(self):
        super().__init__(label="🛒 Buy", style=discord.ButtonStyle.success, custom_id="comprar")

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.send_message("Select your payment method:", view=PagoView(), ephemeral=True)

# Botón para el Showcase (CUSTOM CLASS para manejar el DM)
class ShowcaseButton(discord.ui.Button):
    def __init__(self, url: str):
        super().__init__(label="🎬 Showcase", style=discord.ButtonStyle.secondary, custom_id="showcase_dm")
        self.showcase_url = url

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True) # Acknowledge the interaction

        try:
            # ENVIAR EL LINK AL MENSAJE DIRECTO (DM)
            await interaction.user.send(f"Here is the demo link (Showcase):\n\n{self.showcase_url}")
            await interaction.followup.send("✅ Look MD", ephemeral=True)
        except discord.errors.Forbidden:
            await interaction.followup.send(
                "❌ I couldn't send you the private message. Make sure your DMs are open for this server.", 
                ephemeral=True
            )


class CompraView(discord.ui.View):
    def __init__(self, showcase_url: str | None = None):
        super().__init__(timeout=None)
        if showcase_url:
            self.add_item(ShowcaseButton(showcase_url))
        self.add_item(ComprarButton())


class BuyPersistentView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(ComprarButton())



class BotPanelCog(commands.Cog):
    def __init__(self, bot_):
        self.bot = bot_

    @app_commands.command(name="sendbot", description="Send")
    @app_commands.describe(
        canal_id="ID",
        showcase_url="Showcase"
    )
    @app_commands.checks.has_permissions(manage_guild=True)
    async def send_bot(
        self,
        interaction: discord.Interaction,
        canal_id: str, # Cambiado de discord.TextChannel a str
        showcase_url: str | None = None,
    ):
        await interaction.response.defer(ephemeral=True) # Acknowledge the interaction

        try:
            # INTENTO DE OBTENER EL CANAL POR ID
            canal_id_int = int(canal_id)
            canal = self.bot.get_channel(canal_id_int)

            if not canal or not isinstance(canal, discord.TextChannel):
                await interaction.followup.send(f"❌ No se encontró un canal de texto válido con el ID: `{canal_id}`. Asegúrate de que el bot esté en el servidor.", ephemeral=True)
                return
            
            # USAR CONSTANTES HARDCODEADAS
            
            # Descripción envuelta en bloques de código
            descripcion_final = f"```{PRODUCTO_DESCRIPCION}```\n\n  {PRODUCTO_PRECIO}"
            
            embed = discord.Embed(
                title=PRODUCTO_TITULO,
                description=descripcion_final,
                color=discord.Color.dark_grey(),
            )


            # Usar la clase CompraView que ahora tiene el botón Showcase con DM
            view = CompraView(showcase_url=showcase_url)
            
            await canal.send(embed=embed, view=view)
            await interaction.followup.send(f"✅ Anuncio de '{PRODUCTO_TITULO}' enviado a <#{canal.id}>.", ephemeral=True)

        except ValueError:
            await interaction.followup.send("❌ El ID del canal debe ser un número entero válido.", ephemeral=True)
        except Exception as e:
            log.exception(f"Error al enviar el anuncio: {e}")
            await interaction.followup.send(f"❌ Ocurrió un error al intentar enviar el anuncio: {e}", ephemeral=True)

# =========================
# ======= SYNC / RUN ======
# =========================

@bot.event
async def on_ready():
    bot.add_view(BuyPersistentView())
    try:
        synced = await bot.tree.sync()
        log.info(f"✅ Slash commands sincronizados ({len(synced)} comandos) como {bot.user} ({bot.user.id})")
    except Exception as e:
        log.exception("Error al sincronizar comandos: %s", e)
    log.info("Bot listo.")

@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    log.exception("Error en slash command: %s", error)
    try:
        await interaction.response.send_message(f"⚠️ Error: {error}", ephemeral=True)
    except discord.InteractionResponded:
        await interaction.followup.send(f"⚠️ Error: {error}", ephemeral=True)

async def main():
    async with bot:
        await bot.add_cog(BotPanelCog(bot))
        if not TOKEN or TOKEN == "TU_TOKEN_AQUI":
            raise RuntimeError("Debes poner tu token en la variable TOKEN.")
        await bot.start(TOKEN)

if __name__ == "__main__":
    asyncio.run(main())