import discord
from discord.ext import commands, tasks
import json
import os
import sqlite3 
from datetime import datetime, timedelta
import re
import aiohttp
import asyncio
import platform
import subprocess
import random
import string
import requests
import aiosqlite 
import uuid
import unicodedata
import aiofiles 
import io 
import decimal
import io as io 
import textwrap
import threading
import time
import tempfile
import orjson
from io import BytesIO
import concurrent
import ijson
from discord.ui import View, button, Button
from concurrent.futures import ProcessPoolExecutor, as_completed
from whoosh.index import create_in, open_dir
from whoosh.fields import Schema, TEXT, ID
from whoosh.qparser import QueryParser
from discord.ext import commands
import aiosqlite
from elasticsearch import Elasticsearch
import warnings
import io 
from urllib3.exceptions import InsecureRequestWarning
import ast
import sys
import importlib

warnings.simplefilter('ignore', DeprecationWarning)
warnings.simplefilter('ignore', InsecureRequestWarning)
warnings.filterwarnings('ignore', message="Connecting to 'https://localhost:9200' using TLS with verify_certs=False is insecure")

es = Elasticsearch(
    ['https://127.0.0.1:9200'],
    basic_auth=('elastic', 'ItGxVOnAKMJA0TQoMX3L'), # <-- Pega tu contraseña aquí
    verify_certs=False
)

TOKEN = 'MTM3MTE3MjE5NTU2ODQ1NTg0MQ.GxGfRh.1glwulZTZ9JHnC-3iDRawmilfpktW7qpSnJ3pI'  
PREFIX = '/'
OWNER_ID = "1365004071307841596"  
INDEX_NAME = "c1bot"
LICENSE_DB = "licencias.db"
LOG_WEBHOOK_URL = "https://discord.com/api/webhooks/1389996737338282074/dhoBSZkcntpVkhY64k1zkzkEkaebfHGIeFNGYgfrRzbxndwW-pgOdkmcju0I557hERdA"  

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents)

stop_threads = False
request_count = 0
count_lock = threading.Lock()
final_message_sent = False

active_scans_data = {}

# Variable global para almacenar el código editado
edited_code = None
code_edit_session = {}

# Función para recargar módulos del bot
async def reload_bot_modules():
    """Recarga los módulos del bot para aplicar cambios en vivo."""
    try:
        # Recargar el módulo principal
        importlib.reload(sys.modules[__name__])
        return True
    except Exception as e:
        print(f"Error al recargar módulos: {e}")
        return False

async def ensure_table_exists():
    """Crea la tabla redeem_keys si no existe."""
    async with aiosqlite.connect(LICENSE_DB) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS redeem_keys (
                redeem_key TEXT,
                key_name TEXT,
                duration_seconds INTEGER,
                generator_discord_id TEXT,
                is_used INTEGER,
                created_at TEXT
            )
        """)
        await db.commit()

@bot.command(name="ping")
async def ping_command(ctx, *, host: str):
    import subprocess
    import platform

    start_time = datetime.now()
    await ctx.send(f"📡 `{host}`...")

    param = "-n" if platform.system().lower() == "windows" else "-c"
    command = ["ping", param, "1", host]

    try:
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=5)
        success = result.returncode == 0
    except Exception as e:
        success = False
        result = None

    elapsed = (datetime.now() - start_time).total_seconds()

    if success:
        await ctx.send(f"✅ `{host}` responde al ping.\n⌚ Tiempo: `{elapsed:.3f}s`")
        log_embed = discord.Embed(
            title="✅",
            description=f"El usuario <@{ctx.author.id}> hizo ping a `{host}`.",
            color=discord.Color.green()
        )
        log_embed.add_field(name="Resultado", value="Recibió respuesta", inline=False)
    else:
        await ctx.send(f"❌ `{host}` no responde al ping.\n⌚ Tiempo: `{elapsed:.3f}s`")
        log_embed = discord.Embed(
            title="❌",
            description=f"El usuario <@{ctx.author.id}> intentó hacer ping a `{host}`.",
            color=discord.Color.red()
        )
        log_embed.add_field(name="Resultado", value="No recibió respuesta", inline=False)

    log_embed.set_footer(text=f"Usuario: {ctx.author.name} ({ctx.author.id}) | Tiempo: {elapsed:.3f}s")
    await enviar_webhook(f"Ping ejecutado por {ctx.author.name}", embeds=[log_embed])




def clean_phone_number(phone_input):
    """
    Limpia un número de teléfono, dejando solo dígitos.
    Ej: "642 37 12 83" -> "642371283"
    Ej: "+34642371283" -> "34642371283"
    """
    if phone_input is None:
        return None
    cleaned = re.sub(r'\D', '', str(phone_input))
    return cleaned if cleaned else None



def generar_clave(length=12):
    """Genera una clave alfanumérica aleatoria."""
    characters = string.ascii_uppercase + string.digits
    return ''.join(random.choice(characters) for i in range(length))

async def enviar_webhook(content=None, embeds=None):
    """Envía un mensaje a un webhook de Discord."""
    if not LOG_WEBHOOK_URL:
        print("Advertencia: No se ha configurado la URL del webhook.")
        return

    try:
        webhook = discord.Webhook.from_url(LOG_WEBHOOK_URL, client=bot)
        await webhook.send(content=content, embeds=embeds, username="Bot de Licencias")
    except discord.WebhookException as e:
        print(f"Error al enviar al webhook: {e}")
        

def format_duration(total_seconds):
    if total_seconds >= 86400 and total_seconds % 86400 == 0:
        days = total_seconds // 86400
        return f"{days} días"
    elif total_seconds >= 3600 and total_seconds % 3600 == 0:
        hours = total_seconds // 3600
        return f"{hours} horas"
    elif total_seconds >= 60 and total_seconds % 60 == 0:
        minutes = total_seconds // 60
        return f"{minutes} minutos"
    else:
        return f"{total_seconds} segundos"

async def check_license(user_id):
    """Verifica si un usuario tiene una licencia activa."""
    conn = None
    try:
        conn = await aiosqlite.connect(LICENSE_DB)
        cursor = await conn.cursor()
        
        await cursor.execute("SELECT expiration_date FROM licencias WHERE user_id = ?", (str(user_id),))
        license_data = await cursor.fetchone()

        if license_data:
            expiration_date_str = license_data[0]
            try:
                expiration_dt = datetime.strptime(expiration_date_str, "%Y-%m-%d %H:%M:%S")
                return expiration_dt > datetime.now()
            except ValueError:
                # Esto manejaría casos donde la fecha en la DB no tiene el formato esperado
                print(f"Advertencia: Fecha de expiración inválida en DB para el usuario {user_id}: {expiration_date_str}")
                return False
        return False
    except aiosqlite.Error as e:
        print(f"Error en la verificación de licencia para el usuario {user_id}: {e}")
        return False
    finally:
        if conn:
            await conn.close()


@bot.event
async def on_ready():
    print(f'✅ Bot "{bot.user.name}" is online and ready!')
    try:
        # Aquí eliminamos 'await'
        if es.ping():
            print("✅ Conexión con Elasticsearch exitosa.")
        else:
            print("❌ No se pudo conectar a Elasticsearch.")
    except Exception as e:
        print(f"❌ Error al conectar a Elasticsearch: {e}")



class PlayerInfoView(discord.ui.View):
    def __init__(self, player_data: dict, command_origin: str):
        super().__init__(timeout=180) 
        self.player_data = player_data
        self.command_origin = command_origin

    @discord.ui.button(label="📜", style=discord.ButtonStyle.secondary, custom_id="view_raw_json")
    async def view_raw_json(self, interaction: discord.Interaction, button: discord.ui.Button):
        
        raw_json_string = self.player_data.get("raw_json_data")
        
        if raw_json_string:
            try:
                parsed_json = json.loads(raw_json_string)
                pretty_json_output = json.dumps(parsed_json, ensure_ascii=False, indent=4)
            except json.JSONDecodeError:
                pretty_json_output = raw_json_string

            if len(pretty_json_output) > 1900:
                file_content = discord.File(
                    fp=io.StringIO(pretty_json_output),
                    filename=f"raw_data_{self.player_data.get('id_usuario', 'desconocido')}.json"
                )
                await interaction.response.send_message(f"Aquí está el JSON original para **{self.player_data.get('full_name') or self.player_data.get('id_usuario', 'este usuario')}**:", file=file_content, ephemeral=True)
            else:
                await interaction.response.send_message(f"```json\n{pretty_json_output}\n```", ephemeral=True)
        else:
            await interaction.response.send_message("No hay datos JSON originales disponibles para este registro.", ephemeral=True)
            
    @discord.ui.button(label="🪪", style=discord.ButtonStyle.gray, custom_id="copy_dni", row=0)
    async def copy_dni_button(self, interaction: discord.Interaction, button: discord.ui.Button):

        if str(interaction.user.id) != OWNER_ID and not await check_license(interaction.user.id):
            return await interaction.response.send_message("❌ Sin permisos para usar este botón.", ephemeral=True)

        dni_value = self.player_data.get("dni") or self.player_data.get("DNI")
        if dni_value:
            await interaction.response.send_message(f"Copiado: `{dni_value}`", ephemeral=True)
        else:
            await interaction.response.send_message("No hay DNI disponible para copiar.", ephemeral=True)

    @discord.ui.button(label="📞", style=discord.ButtonStyle.gray, custom_id="copy_phone", row=0)
    async def copy_phone_button(self, interaction: discord.Interaction, button: discord.ui.Button):

        if str(interaction.user.id) != OWNER_ID and not await check_license(interaction.user.id):
            return await interaction.response.send_message("❌ Sin permisos para usar este botón.", ephemeral=True)

        phone_value = self.player_data.get("phone") or self.player_data.get("Teléfono Alumno") or self.player_data.get("Teléfono Urgencia") or self.player_data.get("telefono")
        if phone_value:
            await interaction.response.send_message(f"Copiado: `{phone_value}`", ephemeral=True)
        else:
            await interaction.response.send_message("No hay Teléfono disponible para copiar.", ephemeral=True)

    @discord.ui.button(label="", style=discord.ButtonStyle.gray, emoji="📋")
    async def copiar(self, interaction: discord.Interaction, button: discord.ui.Button):

        if str(interaction.user.id) != OWNER_ID and not await check_license(interaction.user.id):
            return await interaction.response.send_message("❌ Sin permisos para usar este botón.", ephemeral=True)

        texto = ""
        if self.command_origin == "fivem":
            texto = (
                f"Nombre: {self.player_data.get('player_name', 'N/A')}\n"
                f"ID: {self.player_data.get('player_id', 'N/A')}\n"
                f"Discord ID: {self.player_data.get('discord_id', 'N/A')}\n"
                f"Steam: {self.player_data.get('steam_id', 'N/A')}\n"
                f"Job: {self.player_data.get('job', 'N/A')}\n"
                f"Permisos: {self.player_data.get('permissions', 'N/A')}\n"
                f"IP: {self.player_data.get('ip_address', 'N/A')}"
            )
        elif self.command_origin == "spain":
            texto = (
                f"ID Usuario: {self.player_data.get('user_id', 'N/A')}\n"
                f"Nombre Completo: {self.player_data.get('full_name', 'N/A')}\n"
                f"DNI: {self.player_data.get('dni', 'N/A')}\n"
                f"IBAN: {self.player_data.get('iban', 'N/A')}\n"
                f"Email: {self.player_data.get('email', 'N/A')}\n"
                f"Teléfono: {self.player_data.get('phone', 'N/A')}\n"
                f"IP: {self.player_data.get('ip_address', 'N/A')}\n"
                f"Ciudad: {self.player_data.get('city', 'N/A')}\n"
                f"País: {self.player_data.get('country', 'N/A')}\n"
                f"Dirección: {self.player_data.get('address', 'N/A')}\n"
                f"Fecha de Nacimiento: {self.player_data.get('date_of_birth', 'N/A')}\n"
                f"Sistema Operativo: {self.player_data.get('operating_system', 'N/A')}\n"
                f"Mensaje Login: {self.player_data.get('login_message', 'N/A')}\n"
                f"Fecha Login: {self.player_data.get('login_date', 'N/A')}\n"
                f"Archivo Origen: {self.player_data.get('source_file', 'N/A')}"
            )
        elif self.command_origin == "educastur" or self.command_origin == "allys":
            texto = (
                f"ID Alumno: {self.player_data.get('ID Alumno', 'N/A')}\n"
                f"Nombre Completo: {self.player_data.get('Nombre Completo', 'N/A')}\n"
                f"DNI: {self.player_data.get('DNI', 'N/A')}\n"
                f"Email: {self.player_data.get('Email', 'N/A')}\n"
                f"IBAN: {self.player_data.get('IBAN', 'N/A')}\n"
                f"Domicilio: {self.player_data.get('Domicilio', 'N/A')}\n"
                f"IP Address: {self.player_data.get('ip_address', 'N/A')}\n"
                f"Ciudad: {self.player_data.get('city', 'N/A')}\n"
                f"País: {self.player_data.get('country', 'N/A')}\n"
                f"Teléfono Alumno: {self.player_data.get('Teléfono Alumno', 'N/A')}\n"
                f"Teléfono Urgencia: {self.player_data.get('Teléfono Urgencia', 'N/A')}\n"
                f"Primer Tutor: {self.player_data.get('Primer Tutor', 'N/A')}\n"
                f"Teléfono Primer Tutor: {self.player_data.get('Teléfono Tutor 1', 'N/A')}\n"
                f"Segundo Tutor: {self.player_data.get('Segundo Tutor', 'N/A')}\n"
                f"Teléfono Segundo Tutor: {self.player_data.get('Teléfono Tutor 2', 'N/A')}\n"
                f"Fecha Creación: {self.player_data.get('Fecha Creación', 'N/A')}\n"
                f"Última Actualización: {self.player_data.get('Última Actualización', 'N/A')}"
            )
        await interaction.response.send_message(f"```\n{texto}\n```", ephemeral=True)

    @discord.ui.button(label="", style=discord.ButtonStyle.gray, emoji="📍")
    async def track_button_callback(self, interaction: discord.Interaction, button: discord.ui.Button):

        if str(interaction.user.id) != OWNER_ID and not await check_license(interaction.user.id):
            return await interaction.response.send_message("❌ Sin permisos para usar este botón.", ephemeral=True)

        ip_address = self.player_data.get('ip_address')
        if not ip_address or ip_address == 'N/A':
            ip_address = self.player_data.get('IP')
            
        if not ip_address or ip_address == 'N/A' or not re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", ip_address):
            await interaction.response.send_message("❌ No hay una dirección IP válida para rastrear para este jugador.", ephemeral=True)
            return

        await interaction.response.send_message(f"⏳ Rastreado IP `{ip_address}`. Esto puede tardar unos segundos...", ephemeral=True)

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"http://ip-api.com/json/{ip_address}?fields=status,message,country,countryCode,regionName,city,zip,lat,lon,timezone,isp,org,as,query") as response:
                    if response.status == 200:
                        data = await response.json()
                        if data['status'] == 'success':
                            details = (
                                f"**IP:** {data.get('query', 'N/A')}\n"
                                f"**País:** {data.get('country', 'N/A')} ({data.get('countryCode', 'N/A')})\n"
                                f"**Región:** {data.get('regionName', 'N/A')}\n"
                                f"**Ciudad:** {data.get('city', 'N/A')}\n"
                                f"**Código Postal:** {data.get('zip', 'N/A')}\n"
                                f"**Latitud/Longitud:** {data.get('lat', 'N/A')}, {data.get('lon', 'N/A')}\n"
                                f"**Zona Horaria:** {data.get('timezone', 'N/A')}\n"
                                f"**ISP (Proveedor de Internet):** {data.get('isp', 'N/A')}\n"
                                f"**Organización:** {data.get('org', 'N/A')}\n"
                                f"**AS (Sistema Autónomo):** {data.get('as', 'N/A')}"
                            )
                            await interaction.followup.send(f"**Detalles de la IP:**\n{details}", ephemeral=True)
                        else:
                            await interaction.followup.send(f"❌ Error al obtener detalles de la IP: {data.get('message', 'Desconocido')}", ephemeral=True)
                    else:
                        await interaction.followup.send(f"❌ Error en la solicitud a la API de IP: Código de estado {response.status}", ephemeral=True)
        except aiohttp.ClientError as e:
            await interaction.followup.send(f"❌ Error de conexión al servicio de IP: {e}", ephemeral=True)
        except json.JSONDecodeError:
            await interaction.followup.send("❌ Error al procesar la respuesta de la API de IP (JSON inválido).", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ Ocurrió un error inesperado al rastrear la IP: {e}", ephemeral=True)

    @discord.ui.button(label="", style=discord.ButtonStyle.gray, emoji="📡")
    async def ping_button_callback(self, interaction: discord.Interaction, button: discord.ui.Button):

        if str(interaction.user.id) != OWNER_ID and not await check_license(interaction.user.id):
            return await interaction.response.send_message("❌ Sin permisos para usar este botón.", ephemeral=True)

        ip_address = self.player_data.get('ip_address')
        if not ip_address or ip_address == 'N/A':
            ip_address = self.player_data.get('IP')

        if not ip_address or ip_address == 'N/A' or not re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", ip_address):
            await interaction.response.send_message("❌ No hay una dirección IP válida para hacer ping para este jugador.", ephemeral=True)
            return

        await interaction.response.send_message(f"⏳ Haciendo ping a `{ip_address}`. Esto puede tardar unos segundos...", ephemeral=True)

        try:
            if platform.system() == "Windows":
                command = ["ping", "-n", "4", ip_address]
            else:
                command = ["ping", "-c", "4", ip_address]

            process = await asyncio.create_subprocess_exec(
                *command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )

            stdout, stderr = await process.communicate()
            ping_output = stdout.decode('utf-8', errors='ignore').strip()
            error_output = stderr.decode('utf-8', errors='ignore').strip()

            if process.returncode == 0:
                packet_loss_match = re.search(r"(\d+)% packet loss", ping_output)
                stats_match = re.search(r"min/avg/max/mdev = [\d.]+/([\d.]+)/[\d.]+/[\d.]+ ms", ping_output)
                windows_summary_match = re.search(r"Paquetes: Enviados = (\d+), Recibidos = (\d+), Perdidos = (\d+) \((\d+)% de pérdida\)", ping_output)
                windows_rtt_match = re.search(r"Mínimo = (\d+)ms, Máximo = (\d+)ms, Promedio = (\d+)ms", ping_output)

                packet_loss = "N/A"
                avg_rtt = "N/A"

                if packet_loss_match:
                    packet_loss = packet_loss_match.group(1) + "%"

                if stats_match:
                    avg_rtt = stats_match.group(1) + "ms (promedio)"
                elif windows_summary_match and windows_rtt_match:
                    avg_rtt = windows_rtt_match.group(3) + "ms (promedio)"

                if packet_loss == "N/A" and avg_rtt == "N/A":
                    response_message = (
                        f"📡 **Resultados del Ping para `{ip_address}`**\n"
                        f"No se pudo parsear el resultado de ping de forma estándar. "
                        f"A continuación se muestra la salida completa:\n```\n{ping_output}\n```"
                    )
                else:
                    response_message = (
                        f"📡 **Resultados del Ping para `{ip_address}`**\n"
                        f"➡️ **Pérdida de Paquetes:** {packet_loss}\n"
                        f"➡️ **Tiempo Promedio (RTT):** {avg_rtt}"
                    )

                await interaction.followup.send(response_message, ephemeral=True)
            else:
                error_details = []
                if "100% packet loss" in ping_output:
                    error_details.append("100% de pérdida de paquetes")
                if "Host Unreachable" in ping_output or "Destination Host Unreachable" in ping_output:
                    error_details.append("Host inalcanzable/bloqueado")
                if "timed out" in ping_output or "tiempo de espera agotado" in ping_output:
                    error_details.append("Tiempo de espera agotado (host no respondió)")

                if error_details:
                    await interaction.followup.send(f"❌ Ping a `{ip_address}` falló: {', '.join(error_details)}.", ephemeral=True)
                else:
                    full_error_output = f"{ping_output}\n{error_output}".strip()
                    await interaction.followup.send(f"❌ Error desconocido al hacer ping a `{ip_address}`. Código de salida: {process.returncode}. Salida:\n```\n{full_error_output if full_error_output else 'No hay salida de error.'}\n```", ephemeral=True)

        except FileNotFoundError:
            await interaction.followup.send("❌ El comando 'ping' no se encontró en el sistema. Asegúrate de que esté instalado y en tu PATH.", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"❌ Ocurrió un error inesperado al hacer ping: {e}", ephemeral=True)
            


def generar_clave():
    return ''.join(random.choices(string.ascii_letters + string.digits, k=16))

async def eliminar_usuario(user_id):
    try:
        conn = await aiosqlite.connect(LICENSE_DB)
        cursor = await conn.cursor()
        
        await cursor.execute("SELECT * FROM licencias WHERE user_id = ?", (user_id,))
        if await cursor.fetchone():
            await cursor.execute("DELETE FROM licencias WHERE user_id = ?", (user_id,))
            await conn.commit()
            return "✅ Usuario eliminado correctamente."
        else:
            return "❌ No se encontró al usuario."
    except Exception as e:
        return f"⚠️ Error al eliminar usuario: {e}"
    finally:
        if conn:
            await conn.close()


async def enviar_webhook(texto, embeds=None):
    if not LOG_WEBHOOK_URL:
        print("Advertencia: LOG_WEBHOOK_URL no configurado. No se enviará el webhook.")
        return
    async with aiohttp.ClientSession() as session:
        webhook = discord.Webhook.from_url(LOG_WEBHOOK_URL, session=session)
        try:
            return await webhook.send(content=texto, embeds=embeds, username="Bot", avatar_url="https://i.imgur.com/FxW9t9o.png")
        except discord.errors.HTTPException as e:
            print(f"ERROR: No se pudo enviar el webhook. Asegúrate de que la URL sea válida y el bot tenga permisos. Error: {e}")
            return None



def construir_query_flexible(query_term: str):
    """
    Construye una consulta Elasticsearch flexible que permita buscar
    nombre completo, parcial, DNI, email, etc.
    """
    # Separamos los términos ingresados
    terms = query_term.strip().lower().split()

    # Campos relevantes para buscar
    campos_texto = [
        "nombre",
        "apellidos",
        "nombre_completo",
        "nombre_invertido",
        "file",
        "content",
        "telefono",
        "telefono_alumno",
        "telefono_urgencia",
        "telefono_tutor_1",
        "telefono_tutor_2",
        "email",
        "dni"
    ]

    # Si solo hay un término y parece un número o email, buscar directamente
    if len(terms) == 1 and (terms[0].isdigit() or "@" in terms[0]):
        return {
            "query": {
                "multi_match": {
                    "query": query_term,
                    "fields": campos_texto,
                    "operator": "and"
                }
            }
        }

    # Para varios términos, usar bool + must
    return {
        "query": {
            "bool": {
                "must": [
                    {
                        "multi_match": {
                            "query": term,
                            "fields": campos_texto,
                            "operator": "and"
                        }
                    } for term in terms
                ]
            }
        }
    }



# Comando principal
@bot.command(name="c1")
async def spain(ctx, *, query_term: str):
    """
    Busca información de un usuario en todos los campos de Elasticsearch
    y devuelve solo los datos de origen (el campo _source) en un archivo JSON adjunto.
    Uso: !c1 <termino_busqueda>
    Ejemplo: !c1 yuri santana
    """
    if str(ctx.author.id) != OWNER_ID:
        if not await check_license(ctx.author.id):
            return await ctx.send("❌ Inactive license")

    start_time = datetime.now()
    await ctx.send(f"`🔎`", delete_after=5)

    MAX_RESULTS = 100

    try:
        query = construir_query_flexible(query_term)
        response = es.search(index=INDEX_NAME, body=query, size=MAX_RESULTS)

        total_hits = response['hits']['total']['value']
        hits = response['hits']['hits']

        if total_hits > 0 and hits:
            filtered_results = [hit['_source'] for hit in hits if '_source' in hit]

            json_output = json.dumps(filtered_results, indent=2, ensure_ascii=False)
            file_to_send = io.StringIO(json_output)
            discord_file = discord.File(file_to_send, filename="resultados.json")

            await ctx.send(file=discord_file)

            


            log_embed = discord.Embed(
                title="[+] Busqueda en c1.priv",
                description=f"El usuario <@{ctx.author.id}> ha buscado en la base de datos.",
                color=discord.Color.green()
            )
            log_embed.add_field(name="Término de Búsqueda", value=query_term, inline=True)
            log_embed.add_field(name="Resultados", value=f"Se encontraron {total_hits}. Se mostraron {len(hits)}.", inline=False)
            log_embed.set_footer(text=f"Usuario: {ctx.author.name} ({ctx.author.id})")
            await enviar_webhook(f"Búsqueda en base de datos de España por {ctx.author.name}", embeds=[log_embed])

        else:
            await ctx.send("❗ No se encontró ningún resultado.")

            log_embed = discord.Embed(
                title="❌ Búsqueda de Datos",
                description=f"El usuario <@{ctx.author.id}> intentó buscar en la base de datos de España.",
                color=discord.Color.red()
            )
            log_embed.add_field(name="Término de Búsqueda", value=query_term, inline=True)
            log_embed.add_field(name="Motivo", value="No se encontraron resultados.", inline=False)
            log_embed.set_footer(text=f"Usuario: {ctx.author.name} ({ctx.author.id})")
            await enviar_webhook(f"Búsqueda en base de datos de España fallida por {ctx.author.name}", embeds=[log_embed])

    except Exception as e:
        print(f"ERROR: Ocurrió un error: {e}")
        await ctx.send(f"❌ Ocurrió un error al buscar en la base de datos: {e}")

    end_time = datetime.now()
    response_time = (end_time - start_time).total_seconds()
    await ctx.send(f"`⌚ Time: {response_time:.4f}s`")
  

@bot.command(name="generar")
async def generar(ctx, user_id: str, duration_days: int):
    """
    Genera una licencia para un usuario específico con una duración en días.
    Solo para el dueño del bot.
    Uso: !generar <ID_de_usuario> <duracion_dias>
    Ejemplo: !generar 754014180708712478 30
    """
    if str(ctx.author.id) != OWNER_ID:
        return await ctx.send("❌ ¡No tienes permisos para usar este comando!")

    await ctx.send("Generando licencia...", delete_after=3)

    conn = None
    try:
        conn = await aiosqlite.connect(LICENSE_DB)
        cursor = await conn.cursor()

        

        expiration_date = datetime.now() + timedelta(days=duration_days)
        expiration_date_str = expiration_date.strftime("%Y-%m-%d %H:%M:%S")

        await cursor.execute("SELECT expiration_date FROM licencias WHERE user_id = ?", (user_id,))
        existing_license = await cursor.fetchone()

        
        username = "Usuario Desconocido"
        try:
            user = await bot.fetch_user(user_id)
            if user:
                username = str(user)
        except discord.NotFound:
            pass 

        if existing_license:
            
            await cursor.execute("UPDATE licencias SET expiration_date = ?, username = ? WHERE user_id = ?", (expiration_date_str, username, user_id))
            message = f"✅ Licencia de **{username}** (ID: `{user_id}`) actualizada hasta el `{expiration_date_str}`."
        else:
            await cursor.execute("INSERT INTO licencias (username, expiration_date, user_id) VALUES (?, ?, ?)", (username, expiration_date_str, user_id))
            message = f"✅ Licencia generada para **{username}** (ID: `{user_id}`) hasta el `{expiration_date_str}`."
        
        await conn.commit()
        await ctx.send(message)

        embed = discord.Embed(
            title="🎫 Licencia Generada/Actualizada",
            description=message,
            color=discord.Color.green()
        )
        embed.set_footer(text=f"Generado por: {ctx.author.name} ({ctx.author.id})")
        await enviar_webhook(f"Licencia generada/actualizada por {ctx.author.mention}", embeds=[embed])

    except aiosqlite.Error as e:
        await ctx.send(f"❌ Error al interactuar con la base de datos de licencias: {e}")
    except Exception as e:
        await ctx.send(f"❌ Ocurrió un error inesperado: {e}")
    finally:
        if conn:
            await conn.close()



# Función auxiliar para parsear fechas de forma flexible
def parse_date_flexible(date_str: str) -> datetime:
    formats = [
        "%Y-%m-%d %H:%M:%S", # Con segundos (el formato actual que generas)
        "%Y-%m-%d %H:%M",   # Sin segundos (formato antiguo si lo tuvieras)
        "%Y-%m-%d"          # Solo fecha (si tuvieras fechas sin hora)
    ]
    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    raise ValueError(f"No se pudo parsear la fecha: '{date_str}' con ningún formato conocido.")


@bot.command(name="update")
async def update_license(ctx, user: discord.Member, duration_days: int):
    """
    Extiende la licencia de un usuario por un número de días.
    Si la licencia está expirada, la extiende desde el momento actual.
    Uso: !update <@usuario> <dias_a_añadir>
    """
    # 1. Verificación de permisos del OWNER
    if str(ctx.author.id) != OWNER_ID:
        return await ctx.send("❌ ¡No tienes permisos para usar este comando!", ephemeral=True)

    # 2. Validar la duración de los días
    if duration_days <= 0:
        return await ctx.send("❌ La duración en días debe ser un número positivo mayor que cero.")

    conn = None
    try:
        conn = await aiosqlite.connect(LICENSE_DB)
        cursor = await conn.cursor()
        
        user_id = str(user.id)
        username = str(user) # Usa str(user) para obtener el nombre de usuario completo con discriminador si lo tiene

        # 3. Consultar la licencia existente
        await cursor.execute("SELECT expiration_date FROM licencias WHERE user_id = ?", (user_id,))
        result = await cursor.fetchone()
        
        if not result:
            await ctx.send(f"❌ El usuario **{username}** no tiene una licencia activa. Usa `!generar` para crear una.")
            return

        current_expiration_str = result[0]
        
        # 4. Parsear la fecha de expiración existente de forma flexible
        try:
            current_expiration_dt = parse_date_flexible(current_expiration_str)
        except ValueError as e:
            await ctx.send(f"❌ Error al leer la fecha de expiración de la base de datos para **{username}**: {e}. Por favor, contacta a un administrador para revisar el formato de la fecha.")
            return

        # 5. Calcular la nueva fecha de expiración
        status_message = ""
        now = datetime.now()

        if current_expiration_dt < now:
            # Si la licencia ya expiró, la nueva expiración es desde "ahora" + duración
            new_expiration_dt = now + timedelta(days=duration_days)
            status_message = "actualizada (estaba expirada)"
        else:
            # Si la licencia aún es válida, extiende desde la fecha de expiración actual
            new_expiration_dt = current_expiration_dt + timedelta(days=duration_days)
            status_message = "extendida"

        new_expiration_str = new_expiration_dt.strftime("%Y-%m-%d %H:%M:%S") # Guardar siempre con segundos

        # 6. Actualizar la base de datos
        await cursor.execute(
            "UPDATE licencias SET expiration_date = ?, username = ?, updated_at = ? WHERE user_id = ?",
            (new_expiration_str, username, now.strftime("%Y-%m-%d %H:%M:%S"), user_id)
        )
        await conn.commit()
        
        # 7. Enviar confirmación a Discord
        await ctx.send(f"✅ Licencia de **{username}** {status_message} hasta el `{new_expiration_str}`.")

        # 8. Enviar Webhook de Log
        embed = discord.Embed(
            title="🔄 Licencia Extendida",
            description=f"La licencia de {username} ha sido extendida por {duration_days} días.\n"
                        f"Fecha anterior: `{current_expiration_str}`\n"
                        f"Nueva fecha de expiración: `{new_expiration_str}`",
            color=discord.Color.blue()
        )
        embed.set_footer(text=f"Acción realizada por: {ctx.author.name} ({ctx.author.id})")
        await enviar_webhook(f"Licencia extendida por {ctx.author.mention}", embeds=[embed])

    except aiosqlite.Error as e:
        print(f"Error en la base de datos al actualizar licencia: {e}")
        await ctx.send(f"❌ Error en la base de datos: `{e}`")
    except Exception as e: # Captura cualquier otra excepción inesperada
        print(f"Error inesperado al actualizar licencia: {e}")
        await ctx.send(f"❌ Ocurrió un error inesperado al actualizar la licencia: `{e}`")
    finally:
        if conn:
            await conn.close()



@bot.command(name="out")
async def deluser(ctx, user_id: str):
    """
    Elimina un usuario de la base de datos de licencias.
    Solo para el dueño del bot.
    Uso: !deluser <ID_de_usuario>
    Ejemplo: !deluser 123456789012345678
    """
    if str(ctx.author.id) != OWNER_ID:
        return await ctx.send("Error")

    conn = None
    try:
        conn = await aiosqlite.connect(LICENSE_DB)
        cursor = await conn.cursor()
        
        await cursor.execute("DELETE FROM licencias WHERE user_id = ?", (user_id,))
        changes = cursor.rowcount
        await conn.commit()

        if changes > 0:
            message = f"✅ El usuario con ID `{user_id}` ha sido eliminado de la base de datos de licencias."
        else:
            message = f"❗ No se encontró un usuario con ID `{user_id}` en la base de datos."
        
        await ctx.send(message)

        embed = discord.Embed(
            title="🗑️ Usuario Eliminado",
            description=message,
            color=discord.Color.red()
        )
        embed.set_footer(text=f"Acción realizada por: {ctx.author.name} ({ctx.author.id})")
        await enviar_webhook(f"Usuario eliminado por {ctx.author.mention}", embeds=[embed])

    except aiosqlite.Error as e:
        await ctx.send(f"❌ Error al interactuar con la base de datos: {e}")
    except Exception as e:
        await ctx.send(f"❌ Ocurrió un error inesperado: {e}")
    finally:
        if conn:
            await conn.close()



@bot.command(name="list")
async def list_licenses(ctx):
    """
    Muestra la lista de licencias activas y expiradas en un formato de texto simple.
    Solo para el dueño del bot.
    """
    if str(ctx.author.id) != OWNER_ID:
        return await ctx.send("Error")

    conn = None
    try:
        conn = await aiosqlite.connect(LICENSE_DB)
        cursor = await conn.cursor()
        
        await cursor.execute("SELECT username, expiration_date, user_id FROM licencias ORDER BY expiration_date ASC")
        licenses = await cursor.fetchall()
        
        if not licenses:
            return await ctx.send("There are no licenses registered in the database.")

        active_licenses_lines = []
        expired_licenses_lines = []
        
        now = datetime.now()
        
        for license_data in licenses:
            username, expiration_date_str, user_id = license_data
            try:
                expiration_dt = datetime.strptime(expiration_date_str, "%Y-%m-%d %H:%M:%S")

                
                if user_id and user_id.strip():
                    user_obj = bot.get_user(int(user_id))
                    display_name = user_obj.display_name if user_obj else username
                else:
                    
                    display_name = username
                    user_id = "N/A"
                
                
                line = f"{display_name} | {user_id} | {expiration_dt.strftime('%Y-%m-%d %H:%M:%S')}"

                if expiration_dt > now:
                    active_licenses_lines.append(line)
                else:
                    expired_licenses_lines.append(line)
            except ValueError:
                
                invalid_line = f"❌ {username} | {user_id or 'N/A'} | Fecha inválida"
                expired_licenses_lines.append(invalid_line)
        

        if active_licenses_lines:
            # Crea un embed para las licencias activas
            content = "\n".join(active_licenses_lines)
            embed = discord.Embed(
                title="🟢 LICENCIAS ACTIVAS",
                description=f"```fix\n{content}\n```",
                color=discord.Color.green()
            )
            await ctx.send(embed=embed)

        if expired_licenses_lines:
            # Crea un embed para las licencias expiradas
            content = "\n".join(expired_licenses_lines)
            embed = discord.Embed(
                title="🔴 LICENCIAS EXPIRADAS",
                description=f"```fix\n{content}\n```",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
        
        if not active_licenses_lines and not expired_licenses_lines:
            await ctx.send("No licenses found to display.")


    except aiosqlite.Error as e:
        await ctx.send(f"Error: {e}")
    finally:
        if conn:
            await conn.close()






@bot.command(name="gen")
async def genkey(ctx, key_name: str, duration_value: int, duration_unit: str = "d"):
    """
    Genera una clave de canje con duración en segundos, minutos o días.
    Solo para el dueño del bot.
    """
    if str(ctx.author.id) != OWNER_ID:
        return await ctx.send("Error")

    unit_multipliers = {
        's': 1,
        'segundos': 1,
        'm': 60,
        'minutos': 60,
        'h': 3600,
        'horas': 3600,
        'd': 86400,
        'dias': 86400
    }

    unit_lower = duration_unit.lower()
    if unit_lower not in unit_multipliers:
        return await ctx.send(f"❌ Unidad de tiempo no válida. Usa: s, m, h, d.")

    total_seconds = duration_value * unit_multipliers[unit_lower]
    redeem_key = generar_clave()
    created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    generator_discord_id = str(ctx.author.id)

    conn = None
    try:
        # ✅ CREA LA TABLA SI NO EXISTE
        await ensure_table_exists()

        conn = await aiosqlite.connect(LICENSE_DB)
        cursor = await conn.cursor()

        await cursor.execute(
            "INSERT INTO redeem_keys (redeem_key, key_name, duration_seconds, generator_discord_id, is_used, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            (redeem_key, key_name, total_seconds, generator_discord_id, 0, created_at)
        )
        await conn.commit()
        
        formatted_duration = format_duration(total_seconds)
        
        embed = discord.Embed(
            title="🔑 Clave de Canje Generada",
            description=f"**Clave:** `{redeem_key}`\n"
                        f"**Nombre:** `{key_name}`\n"
                        f"**Duración:** `{formatted_duration}`\n"
                        f"**Generada por:** <@{generator_discord_id}>",
            color=discord.Color.dark_gray()
        )
        embed.set_footer(text=f"Creada el: {created_at}")
        await ctx.author.send(embed=embed)
        await ctx.send("✅", ephemeral=True)

        webhook_embed = discord.Embed(
            title="[+] New Key (Registro)",
            description=f"**Nombre:** `{key_name}`\n"
                        f"**Duración:** `{formatted_duration}`\n"
                        f"**Generada por:** <@{generator_discord_id}>",
            color=discord.Color.light_grey()
        )
        webhook_embed.set_footer(text=f"Creada el: {created_at}")
        await enviar_webhook(f"Clave de canje generada por {ctx.author.mention}", embeds=[webhook_embed])

    except aiosqlite.Error as e:
        await ctx.send(f"❌ Error: {e}", ephemeral=True)
    except Exception as e:
        await ctx.send(f"❌: {e}", ephemeral=True)
    finally:
        if conn:
            await conn.close()

@bot.command(name="redeem")
async def canjear(ctx, redeem_key: str):
    """
    Canjea una clave de licencia para obtener tiempo de acceso.
    Uso: !canjear <clave_de_canje>
    Ejemplo: !canjear ABCDEFGHIJKLMN
    """
    await ctx.send("Processing exchange...", delete_after=3)

    user_id = str(ctx.author.id)
    username = str(ctx.author)

    conn = None
    try:
        conn = await aiosqlite.connect(LICENSE_DB)
        cursor = await conn.cursor()

        # ✅ Crear tabla redeem_keys si no existe
        await cursor.execute("""
            CREATE TABLE IF NOT EXISTS redeem_keys (
                redeem_key TEXT,
                key_name TEXT,
                duration_seconds INTEGER,
                generator_discord_id TEXT,
                is_used INTEGER,
                created_at TEXT
            )
        """)
        await conn.commit()

        # ✅ Crear tabla licencias si no existe
        await cursor.execute("""
            CREATE TABLE IF NOT EXISTS licencias (
                username TEXT,
                expiration_date TEXT,
                user_id TEXT
            )
        """)
        await conn.commit()

        # Buscar la clave en la tabla
        await cursor.execute("SELECT redeem_key, duration_seconds, is_used FROM redeem_keys WHERE redeem_key = ?", (redeem_key,))
        key_data = await cursor.fetchone()

        if not key_data:
            await ctx.send("❌ Exchange key invalid or not found.")
            return

        key_value, duration_seconds, is_used = key_data
        if is_used:
            await ctx.send("❌ This redemption key has already been used.")
            return

        # Marcar la clave como usada
        await cursor.execute("UPDATE redeem_keys SET is_used = 1 WHERE redeem_key = ?", (redeem_key,))
        
        # Verificar licencia existente
        await cursor.execute("SELECT expiration_date FROM licencias WHERE user_id = ?", (user_id,))
        existing_license = await cursor.fetchone()

        current_expiration = datetime.now()
        if existing_license:
            try:
                existing_dt = datetime.strptime(existing_license[0], "%Y-%m-%d %H:%M:%S")
                if existing_dt > current_expiration:
                    current_expiration = existing_dt
            except ValueError:
                print(f"Warning: Invalid expiration date for {username}. Using current date.")
                pass

        # Aplicar duración (en segundos)
        new_expiration = current_expiration + timedelta(seconds=duration_seconds)
        new_expiration_str = new_expiration.strftime("%Y-%m-%d %H:%M:%S")

        # Actualizar o crear licencia
        if existing_license:
            await cursor.execute(
                "UPDATE licencias SET expiration_date = ?, username = ? WHERE user_id = ?",
                (new_expiration_str, username, user_id)
            )
            message = f"✅ Your license has been **extended** to `{new_expiration_str}`."
        else:
            await cursor.execute(
                "INSERT INTO licencias (username, expiration_date, user_id) VALUES (?, ?, ?)",
                (username, new_expiration_str, user_id)
            )
            message = f"✅ Your license has been **activated** until `{new_expiration_str}`."

        await conn.commit()
        await ctx.send(message)

        # Log embed
        embed = discord.Embed(
            title="🔑 Clave de Canje Utilizada",
            description=f"La clave `{redeem_key}` ha sido canjeada por <@{user_id}>.\n"
                        f"Nueva fecha de expiración: `{new_expiration_str}`",
            color=discord.Color.orange()
        )
        embed.set_footer(text=f"Usuario: {username} ({user_id})")

        await enviar_webhook(f"Clave de canje utilizada por {ctx.author.mention}", embeds=[embed])

    except aiosqlite.Error as e:
        await ctx.send(f"❌ Error al canjear la clave: {e}")
    except Exception as e:
        await ctx.send(f"❌ Ocurrió un error inesperado al canjear la clave: {e}")
    finally:
        if conn:
            await conn.close()


@bot.command(name="ayuda")
async def help_command_simple(ctx):
    """
    Muestra la lista de comandos disponibles y su uso básico en un embed.
    """
    embed = discord.Embed(
        title="Commands",
        color=discord.Color.dark_embed()
    )
    
    embed.add_field(name="```/c1 <consulta>```", value="Make a query.", inline=False)
    embed.add_field(name="```/ip <IP o URL>```", value="Gets information about an IP or URL.", inline=False)

    embed.set_footer(text="For more details, consult the bot owner. [@c1.gov]")
    
    await ctx.send(embed=embed)
            
bot.run(TOKEN)