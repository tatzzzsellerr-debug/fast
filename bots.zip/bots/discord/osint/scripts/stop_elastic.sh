#!/bin/bash
pkill -f elasticsearch
echo "🛑 Elasticsearch detenido."

