#!/bin/bash
# start-elastic.sh

ES_HOME="$(dirname "$0")/.."
ES_BIN="$ES_HOME/bin/elasticsearch"
ES_DATA="$ES_HOME/data"

echo "💀 Matando procesos de Elasticsearch antiguos..."
pkill -f 'elasticsearch' 2>/dev/null

echo "🧹 Esperando a que se cierren..."
sleep 2

# Limpiar locks antiguos
if [ -d "$ES_DATA" ]; then
    echo "🔒 Eliminando locks en $ES_DATA..."
    find "$ES_DATA" -name "node.lock" -exec rm -f {} \;
fi

echo "🚀 Arrancando Elasticsearch..."
"$ES_BIN"
