#!/bin/bash
cd /home/c1/Downloads/all/zip/elasticsearch-9.1.5-linux-x86_64/elasticsearch-9.1.5
./bin/elasticsearch -d
echo "✅ Elasticsearch iniciado en segundo plano."
