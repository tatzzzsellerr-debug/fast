const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3001;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));

// Crear carpeta de base de datos si no existe
const dbDir = path.join(__dirname, 'database');
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir);
}

// Conectar a la base de datos SQLite (se crea automáticamente)
const dbPath = path.join(dbDir, 'nail_salon.db');
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Error al conectar con la base de datos:', err);
  } else {
    console.log('✓ Base de datos conectada:', dbPath);
    initializeDatabase();
  }
});

// Inicializar tablas
function initializeDatabase() {
  db.serialize(() => {
    // Tabla de usuarios
    db.run(`CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      name TEXT NOT NULL,
      lastName TEXT,
      role TEXT DEFAULT 'client',
      createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Tabla de citas
    db.run(`CREATE TABLE IF NOT EXISTS bookings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      clientEmail TEXT NOT NULL,
      clientName TEXT NOT NULL,
      date TEXT NOT NULL,
      time TEXT NOT NULL,
      nailType TEXT NOT NULL,
      location TEXT NOT NULL,
      price REAL NOT NULL,
      image TEXT,
      status TEXT DEFAULT 'pending',
      createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (clientEmail) REFERENCES users(email)
    )`);

    // Tabla de reseñas
    db.run(`CREATE TABLE IF NOT EXISTS reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      bookingId INTEGER NOT NULL,
      clientName TEXT NOT NULL,
      rating INTEGER NOT NULL,
      comment TEXT NOT NULL,
      date DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (bookingId) REFERENCES bookings(id)
    )`);

    // Crear usuario admin por defecto
    const adminEmail = 'admin@nails.com';
    const adminPassword = 'admin123';
    
    db.get('SELECT * FROM users WHERE email = ?', [adminEmail], async (err, row) => {
      if (!row) {
        const hashedPassword = await bcrypt.hash(adminPassword, 10);
        db.run(
          'INSERT INTO users (email, password, name, role) VALUES (?, ?, ?, ?)',
          [adminEmail, hashedPassword, 'Administrador', 'admin'],
          (err) => {
            if (err) {
              console.error('Error al crear admin:', err);
            } else {
              console.log('✓ Usuario admin creado: admin@nails.com / admin123');
            }
          }
        );
      }
    });

    console.log('✓ Tablas de base de datos inicializadas');
  });
}

// ============= RUTAS DE AUTENTICACIÓN =============

// Registro
app.post('/api/register', async (req, res) => {
  const { email, password, name, lastName } = req.body;

  if (!email || !password || !name) {
    return res.status(400).json({ error: 'Faltan campos requeridos' });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    
    db.run(
      'INSERT INTO users (email, password, name, lastName, role) VALUES (?, ?, ?, ?, ?)',
      [email, hashedPassword, name, lastName || '', 'client'],
      function(err) {
        if (err) {
          if (err.message.includes('UNIQUE')) {
            return res.status(400).json({ error: 'Este email ya está registrado' });
          }
          return res.status(500).json({ error: 'Error al registrar usuario' });
        }
        
        res.json({
          success: true,
          user: {
            id: this.lastID,
            email,
            name: `${name} ${lastName || ''}`,
            role: 'client'
          }
        });
      }
    );
  } catch (error) {
    res.status(500).json({ error: 'Error en el servidor' });
  }
});

// Login
app.post('/api/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email y contraseña requeridos' });
  }

  db.get('SELECT * FROM users WHERE email = ?', [email], async (err, user) => {
    if (err) {
      return res.status(500).json({ error: 'Error en el servidor' });
    }

    if (!user) {
      return res.status(401).json({ error: 'Email o contraseña incorrectos' });
    }

    const validPassword = await bcrypt.compare(password, user.password);
    
    if (!validPassword) {
      return res.status(401).json({ error: 'Email o contraseña incorrectos' });
    }

    res.json({
      success: true,
      user: {
        email: user.email,
        name: `${user.name} ${user.lastName || ''}`.trim(),
        role: user.role
      }
    });
  });
});

// ============= RUTAS DE CITAS =============

// Obtener todas las citas
app.get('/api/bookings', (req, res) => {
  const { clientEmail } = req.query;
  
  let query = 'SELECT * FROM bookings ORDER BY date DESC, time DESC';
  let params = [];
  
  if (clientEmail) {
    query = 'SELECT * FROM bookings WHERE clientEmail = ? ORDER BY date DESC, time DESC';
    params = [clientEmail];
  }
  
  db.all(query, params, (err, rows) => {
    if (err) {
      return res.status(500).json({ error: 'Error al obtener citas' });
    }
    res.json(rows);
  });
});

// Crear cita
app.post('/api/bookings', (req, res) => {
  const { clientEmail, clientName, date, time, nailType, location, price, image } = req.body;

  if (!clientEmail || !clientName || !date || !time || !nailType || !location || !price) {
    return res.status(400).json({ error: 'Faltan campos requeridos' });
  }

  db.run(
    'INSERT INTO bookings (clientEmail, clientName, date, time, nailType, location, price, image) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    [clientEmail, clientName, date, time, nailType, location, price, image || null],
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Error al crear cita' });
      }
      
      res.json({
        success: true,
        booking: {
          id: this.lastID,
          clientEmail,
          clientName,
          date,
          time,
          nailType,
          location,
          price,
          image
        }
      });
    }
  );
});

// Cancelar cita
app.delete('/api/bookings/:id', (req, res) => {
  const { id } = req.params;

  db.run('DELETE FROM bookings WHERE id = ?', [id], function(err) {
    if (err) {
      return res.status(500).json({ error: 'Error al cancelar cita' });
    }
    res.json({ success: true, deletedId: id });
  });
});

// ============= RUTAS DE RESEÑAS =============

// Obtener todas las reseñas
app.get('/api/reviews', (req, res) => {
  db.all('SELECT * FROM reviews ORDER BY date DESC', [], (err, rows) => {
    if (err) {
      return res.status(500).json({ error: 'Error al obtener reseñas' });
    }
    res.json(rows);
  });
});

// Crear reseña
app.post('/api/reviews', (req, res) => {
  const { bookingId, clientName, rating, comment } = req.body;

  if (!bookingId || !clientName || !rating || !comment) {
    return res.status(400).json({ error: 'Faltan campos requeridos' });
  }

  db.run(
    'INSERT INTO reviews (bookingId, clientName, rating, comment) VALUES (?, ?, ?, ?)',
    [bookingId, clientName, rating, comment],
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Error al crear reseña' });
      }
      
      res.json({
        success: true,
        review: {
          id: this.lastID,
          bookingId,
          clientName,
          rating,
          comment,
          date: new Date().toISOString()
        }
      });
    }
  );
});

// Eliminar reseña
app.delete('/api/reviews/:id', (req, res) => {
  const { id } = req.params;

  db.run('DELETE FROM reviews WHERE id = ?', [id], function(err) {
    if (err) {
      return res.status(500).json({ error: 'Error al eliminar reseña' });
    }
    res.json({ success: true, deletedId: id });
  });
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`\n🚀 Servidor corriendo en http://localhost:${PORT}`);
  console.log(`📁 Base de datos: ${dbPath}`);
  console.log(`👑 Admin: admin@nails.com / admin123\n`);
});